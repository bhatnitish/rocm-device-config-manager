#!/usr/bin/env bash
# Install / reinstall DCM on k3s. Run from the directory that contains the chart .tgz and values-k3s.yaml
# (or set CHART_TGZ / VALUES_FILE).
#
# Usage:
#   ./install-k3s.sh                    # uninstall existing release if present, then install (default)
#   ./install-k3s.sh --upgrade-only   # helm upgrade --install only (no uninstall)
#   KUBECONFIG=~/.kube/config-k3s ./install-k3s.sh
#   sudo KUBECONFIG=/etc/rancher/k3s/k3s.yaml ./install-k3s.sh
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RELEASE_NAME="${RELEASE_NAME:-dcm}"
NAMESPACE="${NAMESPACE:-kube-amd-gpu}"
VALUES_FILE="${VALUES_FILE:-${SCRIPT_DIR}/values-k3s.yaml}"

# Discover chart package (prefer explicit env, then v1.4.1 name, then any device-config-manager-charts-*.tgz)
if [[ -n "${CHART_TGZ:-}" && -f "${CHART_TGZ}" ]]; then
  :
elif [[ -f "${SCRIPT_DIR}/device-config-manager-charts-v1.4.1.tgz" ]]; then
  CHART_TGZ="${SCRIPT_DIR}/device-config-manager-charts-v1.4.1.tgz"
else
  CHART_TGZ="$(ls -1 "${SCRIPT_DIR}"/device-config-manager-charts-*.tgz 2>/dev/null | head -1 || true)"
fi

if [[ -z "${CHART_TGZ:-}" || ! -f "${CHART_TGZ}" ]]; then
  echo "error: no chart package found. Expected ${SCRIPT_DIR}/device-config-manager-charts-v1.4.1.tgz" >&2
  exit 1
fi

if [[ ! -f "${VALUES_FILE}" ]]; then
  echo "error: values file not found: ${VALUES_FILE}" >&2
  exit 1
fi

MODE="fresh"
EXTRA_HELM=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --upgrade-only|--no-uninstall)
      MODE="upgrade"
      shift
      ;;
    --fresh|--reinstall)
      MODE="fresh"
      shift
      ;;
    -h|--help)
      sed -n '1,20p' "$0"
      exit 0
      ;;
    --)
      shift
      EXTRA_HELM+=("$@")
      break
      ;;
    *)
      echo "error: unknown option: $1 (try --help)" >&2
      exit 1
      ;;
  esac
done

# k3s kubeconfig if not set
if [[ -z "${KUBECONFIG:-}" ]]; then
  if [[ -r /etc/rancher/k3s/k3s.yaml ]]; then
    export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
  elif [[ -f "${HOME}/.kube/config-k3s" ]]; then
    export KUBECONFIG="${HOME}/.kube/config-k3s"
  fi
fi

HELM_BIN="${HELM_BIN:-helm}"

helm_do() {
  "${HELM_BIN}" "$@"
}

if ! helm_do version >/dev/null 2>&1; then
  echo "error: helm cannot talk to the cluster (KUBECONFIG=${KUBECONFIG:-unset})." >&2
  echo "  export KUBECONFIG=/etc/rancher/k3s/k3s.yaml" >&2
  echo "  or: sudo KUBECONFIG=/etc/rancher/k3s/k3s.yaml $0" >&2
  exit 1
fi

if [[ "${MODE}" == "fresh" ]]; then
  if helm_do status "${RELEASE_NAME}" -n "${NAMESPACE}" >/dev/null 2>&1; then
    echo "Removing existing Helm release ${RELEASE_NAME} in ${NAMESPACE}..."
    helm_do uninstall "${RELEASE_NAME}" -n "${NAMESPACE}"
    echo "Waiting for workload cleanup..."
    sleep 3
  else
    echo "No existing release ${RELEASE_NAME} in ${NAMESPACE} (clean install)."
  fi
fi

echo "Installing ${RELEASE_NAME} (chart: ${CHART_TGZ}, values: ${VALUES_FILE})..."
helm_do upgrade --install "${RELEASE_NAME}" "${CHART_TGZ}" \
  -n "${NAMESPACE}" \
  --create-namespace \
  -f "${VALUES_FILE}" \
  --wait \
  --timeout 10m \
  "${EXTRA_HELM[@]}"

echo "Done."
echo "  kubectl get pods -n ${NAMESPACE} -o wide"
echo "  kubectl logs -n ${NAMESPACE} -l app=amdgpu-device-config-manager --tail=50"
